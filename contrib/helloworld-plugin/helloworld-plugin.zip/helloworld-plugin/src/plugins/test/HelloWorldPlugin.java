/*
 * Copyright (c) 2008-2009 Tomas Varaneckas
 * http://www.varaneckas.com
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package plugins.test;

import org.eclipse.swt.program.Program;

import com.varaneckas.hawkscope.Version;
import com.varaneckas.hawkscope.command.Command;
import com.varaneckas.hawkscope.menu.ExecutableMenuItem;
import com.varaneckas.hawkscope.menu.MainMenu;
import com.varaneckas.hawkscope.plugin.PluginAdapter;
import com.varaneckas.hawkscope.util.IconFactory;

/**
 * Hello World Hawkscope Plugin.
 * 
 * It extends {@link PluginAdapter} which is a stub for creating new plugins.
 * 
 * @author Tomas Varaneckas
 * @version 1.0
 */
public class HelloWorldPlugin extends PluginAdapter {

	/**
	 * Constructor makes this plugin hookable before About menu item
	 */
	public HelloWorldPlugin() {
		canHookBeforeAboutMenuItem = true;
	}
	
	@Override
	public void beforeAboutMenuItem(final MainMenu mainMenu) {
		//we'll add a new Menu item which will open Hawkscope homepage
		//in a browser
		final ExecutableMenuItem hello = new ExecutableMenuItem();
		hello.setText("Hello World!");
		hello.setIcon(IconFactory.getInstance().getUncachedIcon("update24.png"));
		hello.setCommand(new Command() {
			public void execute() {
				Program.launch(Version.HOMEPAGE);
			}
		});
		mainMenu.addMenuItem(hello);
	}
	
	/**
	 * Gets the plugin description
	 */
	public String getDescription() {
		return "Example Hawkscope plugin. Opens " +
				"http://hawkscope.googlecode.com in a browser.";
	}

	/**
	 * Gets the plugin name
	 */
	public String getName() {
		return "Hello World";
	}

	/**
	 * Gets the plugin version
	 */
	public String getVersion() {
		return "1.0";
	}
	
}
